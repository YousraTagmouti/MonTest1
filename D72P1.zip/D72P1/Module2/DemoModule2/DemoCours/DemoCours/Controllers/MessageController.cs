﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DemoCours.Controllers;
using DemoCours.Ressource;
using DemoCours.Models;
using System.Threading;
using System.Globalization;


namespace DemoCours.Controllers
{
    public class MessageController : Controller
    {
        
        public ActionResult Index()
        {
          
            return View("Index");
        }
//Utilisation du modèle
        public ActionResult GetMessage()
        {
            Message mess = new Message();
            mess.Emetteur = "Eni";
            mess.Contenu = "Bienvenue en Web ASP.Net MVC4";
            mess.Date = new DateTime(2017, 09, 08);
            return View(mess);
        }

//utilisation du fichier de resource 
        public ActionResult GetMessageRessource()
        {

            string str;
            str = Request.ServerVariables["HTTP_ACCEPT_LANGUAGE"];
            Message mess = new Message();
            mess.Emetteur = "Yousra";
            mess.Contenu = "Bienvenue en Web ASP.Net MVC4";
            mess.Date = new DateTime(2017, 09, 08);
            if (str.IndexOf("fr")!=-1)
            {
                Thread.CurrentThread.CurrentUICulture = CultureInfo.CreateSpecificCulture("fr");

            }
            else
            {

                Thread.CurrentThread.CurrentUICulture = CultureInfo.CreateSpecificCulture("en");
            }
            
            return View(mess);
        }

         public ActionResult GetInfoMessageAutreUrl()
        {

            return Redirect("/Message/GetInfoMessage");
        }

        public ActionResult CreationMessageHelperGenerique()
        {

            return View();
        }        

    }

}